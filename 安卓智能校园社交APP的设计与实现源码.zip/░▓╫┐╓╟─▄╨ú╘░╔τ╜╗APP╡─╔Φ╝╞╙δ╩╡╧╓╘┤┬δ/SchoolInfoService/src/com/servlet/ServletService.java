package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bean.admins;
import com.bean.tb_collect;
import com.bean.tb_comment;
import com.bean.tb_foods;
import com.bean.tb_news;
import com.bean.tb_pro;
import com.bean.tb_user;

@SuppressWarnings("serial")
public class ServletService extends HttpServlet {
	java.text.SimpleDateFormat nosformatter = new java.text.SimpleDateFormat(
			"yyyyMMddHHmmss");
	java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");
	java.text.SimpleDateFormat formatter1 = new java.text.SimpleDateFormat(
			"HH:mm");
	java.text.SimpleDateFormat formatdate = new java.text.SimpleDateFormat(
			"yyyy-MM-dd");
	private String currentTime = "";// �õ���ǰϵͳʱ��
	private String currentDate = "";// �õ���ǰϵͳ����

	private String write = "";
	private String sqlString;
	private Session session = null;
	private HttpServletRequest request;

	public ServletService() {
		super();
		session = HibernateSessionFactory.getSession();
	}

	@Override
	public void destroy() {
		super.destroy();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		initRequest(request, response);

		PrintWriter out = response.getWriter();
		String action = request.getParameter("Action");
		System.out.println(action);

		// ��¼��֤
		if (action.equals("login")) {

			String loginid = request.getParameter("loginid");
			String password = request.getParameter("password");
			List<tb_user> list = session.createQuery(
					" from tb_user where loginid='" + loginid
							+ "' and password='" + password + "'").list();
			if (list.size() > 0) {
				write = JSONArray.fromObject(list.get(0)).toString();
			}

		}
		// ����Ա��¼��֤
		if (action.equals("adminlogin")) {
			write = adminlogin();
		}
		if (action.equals("Del")) {
			write = Del();
		}
		if (action.equals("getOneRow")) {
			write = getOneRow();
		}

		if (action.equals("getnewlist")) {
			write = getnewlist();
		}
		if (action.equals("getprolist")) {
			write = getprolist();
		}

		if (action.equals("getfoodlist")) {
			write = getfoodlist();
		}
		if (action.equals("getcomment")) {
			write = getcomment();
		}

		if (action.equals("getonepro")) {
			int ID = Integer.valueOf(request.getParameter("ID"));
			sqlString = "select * from tb_pro where id=" + ID;

			write = HibernateSessionFactory.selectToJson(sqlString);

		}
		if (action.equals("getoneuser")) {
			int ID = Integer.valueOf(request.getParameter("ID"));
			sqlString = "select * from tb_user where id=" + ID;
			write = HibernateSessionFactory.selectToJson(sqlString);

		}
		// �޸Ķ���״̬
		if (action.equals("changestate")) {
			int id = Integer.valueOf(request.getParameter("id"));
			List list = session.createQuery(" from tb_pro where id=" + id)
					.list();
			if (list.size() > 0) {
				tb_pro model = (tb_pro) list.get(0);
				model.setState(getChinese(request.getParameter("state")));
				Transaction tran = session.beginTransaction();
				session.save(model);
				tran.commit();
				write = "1";
			}

		}

		if (action.equals("ChangeStatus")) {
			write = changestatus();
		}
		System.out.println(write);
		out.println(write);
		out.flush();
		out.close();
	}

	private String getprolist() {
		String proname = request.getParameter("proname");
		String quality = request.getParameter("quality");
		String typeid = request.getParameter("typeid");
		String userid = request.getParameter("userid");
		String iscollect = request.getParameter("iscollect");
		String status = request.getParameter("status");
		sqlString = "SELECT tb_pro.id,tb_pro.status, tb_pro.proname, tb_pro.userid, tb_pro.filepath, tb_pro.state, tb_pro.quality, tb_pro.typeid, tb_pro.price, tb_pro.intro, tb_pro.createtime,tb_user.phone,tb_user.code, tb_user.`name` username, tb_types.`name` typename FROM tb_pro INNER JOIN tb_types ON tb_types.id = tb_pro.typeid INNER JOIN tb_user ON tb_user.id = tb_pro.userid ";
		sqlString += " where 1=1 ";
		if (!BaseUtil.isEmpty(proname)) {
			sqlString += " and tb_pro.proname like '%" + proname + "%'";
		}
		if (!BaseUtil.isEmpty(quality) && Double.valueOf(quality) > 0) {
			sqlString += " and tb_pro.quality>=" + quality;
		}
		if (!BaseUtil.isEmpty(typeid) && !typeid.equals("0")) {
			sqlString += " and tb_pro.typeid=" + typeid;
		}
		if (!BaseUtil.isEmpty(iscollect)) {
			sqlString += " and tb_pro.id in(select proid from tb_collect where userid="
					+ userid + ")";
		}
		if (!BaseUtil.isEmpty(status)) {
			sqlString += " and tb_pro.status='" + status + "'";
		}
		if (BaseUtil.isEmpty(iscollect)) {
			if (!BaseUtil.isEmpty(userid)) {
				sqlString += " and tb_pro.userid=" + userid;
			} else {
				sqlString += " and tb_pro.state<>'���¼�'";
			}
		}
		sqlString += " order by  tb_pro.createtime desc";
		write = HibernateSessionFactory.selectToJson(sqlString);
		return write;
	}

	private String getnewlist() {
		String write = "";
		String sqlString = "SELECT tb_news.* from tb_news  ";

		sqlString += " order by tb_news.id desc";
		write = HibernateSessionFactory.selectToJson(sqlString);
		return write;
	}

	private String getfoodlist() {
		String write = "";
		String keyword = request.getParameter("keyword");
		String sqlString = "SELECT * from tb_foods  where 1=1 ";
		if (!BaseUtil.isEmpty(keyword)) {
			sqlString += " and name like '%" + keyword + "%'";
		}
		sqlString += " order by id desc";
		write = HibernateSessionFactory.selectToJson(sqlString);
		return write;
	}

	private String getcomment() {
		String id = request.getParameter("id");
		sqlString = "SELECT tb_comment.*, tb_user.`name` username FROM tb_comment INNER JOIN tb_user ON tb_comment.userid = tb_user.id  ";
		sqlString += " where 1=1 ";
		sqlString += " and proid=" + id;
		sqlString += " order by  tb_comment.createtime desc";
		write = HibernateSessionFactory.selectToJson(sqlString);
		return write;
	}

	private String changestatus() {
		int id = Integer.valueOf((request.getParameter("ID")));
		String status = (request.getParameter("status"));
		tb_pro model;
		model = (tb_pro) (session.createQuery(" from tb_pro where id=" + id)
				.list().get(0));
		model.setStatus(status);
		Transaction tran = session.beginTransaction();
		session.save(model);
		tran.commit();
		return "1";
	}

	/**
	 * ȡ������
	 * 
	 * @param ԭ�ַ�
	 * @return
	 */
	private String getChinese(String str) {
		return str;
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		initRequest(request, response);

		PrintWriter out = response.getWriter();
		String action = request.getParameter("Action");
		String write = "";
		// ע��
		if (action.equals("register")) {
			System.out.println(request.getParameter("id"));
			tb_user model = new tb_user();
			if (request.getParameter("id") == null
					|| request.getParameter("id").equals("0")) {
				model = new tb_user();
				model.setCreatetime(currentTime);
			} else {
				model = (tb_user) (session.createQuery(
						" from tb_user where id=" + request.getParameter("id"))
						.list().get(0));
			}
			model.setLoginid(request.getParameter("loginid"));
			model.setPassword(request.getParameter("password"));
			model.setName(getChinese(request.getParameter("name")));
			model.setPhone(request.getParameter("phone"));
			model.setCode(request.getParameter("code"));
			Transaction tran = session.beginTransaction();
			session.save(model);
			tran.commit();
			write = "1";
		}
		// ������Ϣ
		if (action.equals("editpro")) {
			tb_pro model = new tb_pro();
			if (request.getParameter("id") == null
					|| request.getParameter("id").equals("0")) {
				model = new tb_pro();
				model.setCreatetime(currentTime);
				model.setStatus("�����");
			} else {
				model = (tb_pro) (session.createQuery(
						" from tb_pro where id=" + request.getParameter("id"))
						.list().get(0));
			}
			model.setUserid(Integer.valueOf(request.getParameter("userid")));
			if (!BaseUtil.isEmpty(request.getParameter("filename"))) {
				model.setFilepath(getChinese(request.getParameter("filename")));
			}

			model.setIntro(getChinese(request.getParameter("intro")));
			model.setProname(getChinese(request.getParameter("proname")));
			model.setState(getChinese(request.getParameter("state")));
			model.setQuality(Double.valueOf(request.getParameter("quality")));
			model.setPrice(Double.valueOf(request.getParameter("price")));
			model.setTypeid(Integer.valueOf(request.getParameter("typeid")));
			Transaction tran = session.beginTransaction();
			session.saveOrUpdate(model);
			tran.commit();
			write = "1";
		}

		if (action.equals("comment")) {
			tb_comment model = new tb_comment();
			model.setProid(Integer.valueOf(request.getParameter("proid")));
			model.setCreatetime(currentTime);
			model.setComment(getChinese(request.getParameter("comment")));
			model.setUserid(Integer.valueOf(request.getParameter("userid")));
			Transaction tran = session.beginTransaction();
			session.save(model);
			tran.commit();
			write = "1";
		}
		if (action.equals("collect")) {
			write = collect();
		}
		if (action.equals("editnews")) {
			write = editnews();
		}
		if (action.equals("editfood")) {
			write = editfood();
		}

		out.println(write);
		out.flush();
		out.close();
	}

	private String adminlogin() {
		String write = "";
		String loginid = request.getParameter("loginid");
		String passwords = request.getParameter("passwords");
		List<admins> list = session.createQuery(
				" from admins where loginid='" + loginid + "' and passwords='"
						+ passwords + "'").list();
		if (list.size() > 0) {
			write = "1";
		} else {
			write = "0";
		}
		return write;
	}

	public String getOneRow() throws UnsupportedEncodingException {
		if (request.getParameter("ID") == null) {
			sqlString = "select * from " + request.getParameter("Table");
		} else {
			sqlString = "select * from " + request.getParameter("Table")
					+ " where id=" + request.getParameter("ID");
		}

		write = HibernateSessionFactory.selectToJson(sqlString);
		return write;
	}

	public String Del() {
		int ID = Integer.valueOf(request.getParameter("ID"));
		String Table = request.getParameter("Table");
		String PK_Name = "id";
		String sql = "delete from " + Table + " where " + PK_Name + "=" + ID;
		HibernateSessionFactory.updateExecute(sql);
		return "1";

	}

	private String collect() {
		String write = "";
		int userid = Integer.valueOf(request.getParameter("userid"));
		int proid = Integer.valueOf(request.getParameter("proid"));
		List list = session.createQuery(
				" from tb_collect where userid=" + userid + " and proid="
						+ proid).list();
		if (list.size() > 0) {
			write = "-1";
		} else {
			tb_collect model = new tb_collect();
			model.setUserid(Integer.valueOf(request.getParameter("userid")));
			model.setProid(Integer.valueOf(request.getParameter("proid")));
			model.setCreatetime(currentTime);

			Transaction tran = session.beginTransaction();
			session.save(model);
			tran.commit();
			write = "1";
		}
		return write;
	}

	private String editfood() {
		tb_foods model = new tb_foods();
		if (request.getParameter("id") == null
				|| request.getParameter("id").equals("0")) {
			model = new tb_foods();
		} else {
			model = (tb_foods) (session.createQuery(
					" from tb_foods where id=" + request.getParameter("id"))
					.list().get(0));
		}
		if (!BaseUtil.isEmpty(request.getParameter("img_url"))) {
			model.setImg_url(request.getParameter("img_url").trim());
		}
		if (!BaseUtil.isEmpty(request.getParameter("filename"))) {
			model.setImg_url(request.getParameter("filename").trim());
		}
		model.setName(request.getParameter("name"));
		model.setSteps(request.getParameter("steps"));
		model.setMaterial(request.getParameter("material"));
		model.setIntro(request.getParameter("intro"));
		Transaction tran = session.beginTransaction();
		session.save(model);
		tran.commit();
		return "1";
	}

	private String editnews() {
		tb_news model = new tb_news();
		if (request.getParameter("id") == null
				|| request.getParameter("id").equals("0")) {
			model = new tb_news();
			model.setCreatetime(currentTime);
		} else {
			model = (tb_news) (session.createQuery(
					" from tb_news where id=" + request.getParameter("id"))
					.list().get(0));
		}
		if (!BaseUtil.isEmpty(request.getParameter("img_url"))) {
			model.setImg_url(request.getParameter("img_url").trim());
		}
		if (!BaseUtil.isEmpty(request.getParameter("filename"))) {
			model.setImg_url(request.getParameter("filename").trim());
		}
		model.setTitle(request.getParameter("title"));
		model.setBody(request.getParameter("body"));
		model.setKeyword(request.getParameter("keyword"));
		Transaction tran = session.beginTransaction();
		session.save(model);
		tran.commit();
		return "1";
	}

	private void initRequest(HttpServletRequest request,
			HttpServletResponse response) {
		currentTime = formatter.format(new java.util.Date());
		currentDate = formatdate.format(new java.util.Date());

		this.request = request;

		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
	}

	@Override
	public void init() throws ServletException {

	}

}
