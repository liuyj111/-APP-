package com.cm.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cm.activity.R;
import com.cm.bean.tb_news;
import com.cm.utils.AsyncImageLoader;

public class NewsAdapter extends BaseAdapter {
	private List<tb_news> list = null;
	private final Context context;

	public NewsAdapter(Context context, List<tb_news> list) {
		this.context = context;
		this.list = list;

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertview, ViewGroup parent) {
		View view = convertview;
		ViewHolder holder;
		if (view == null) {
			holder = new ViewHolder();
			view = LayoutInflater.from(context).inflate(
					R.layout.listview_item_common, null);

			holder.imageView1 = (ImageView) view.findViewById(R.id.imageView1);
			holder.textView1 = (TextView) view.findViewById(R.id.textView1);
			holder.textView2 = (TextView) view.findViewById(R.id.textView2);
			holder.textView3 = (TextView) view.findViewById(R.id.textView3);
			holder.imageView1.setVisibility(View.VISIBLE);
			view.setTag(holder);
		} else {
			holder = (ViewHolder) view.getTag();

		}
		tb_news model = list.get(position);
		holder.textView1.setText(model.getTitle());
		holder.textView2.setText(model.getCreatetime());
		holder.textView3.setText(model.getBody());
		AsyncImageLoader.getInstance().loadBitmap(model.getImg_url(),
				holder.imageView1);
		return view;

	}

	static class ViewHolder {
		private ImageView imageView1;
		private TextView textView1;
		private TextView textView2;
		private TextView textView3;
	}

}
