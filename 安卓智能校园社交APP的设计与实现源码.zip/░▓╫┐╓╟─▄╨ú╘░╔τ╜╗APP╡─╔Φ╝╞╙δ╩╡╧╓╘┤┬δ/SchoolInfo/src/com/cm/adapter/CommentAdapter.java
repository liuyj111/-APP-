package com.cm.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.cm.activity.R;
import com.cm.bean.tb_comment;

public class CommentAdapter extends BaseAdapter {
	private List<tb_comment> list = null;
	private final Context context;
	private LayoutInflater infater = null;

	public CommentAdapter(Context context, List<tb_comment> list) {
		this.infater = LayoutInflater.from(context);
		this.list = list;
		this.context = context;

	}

	@Override
	public int getCount() {

		return list.size();
	}

	@Override
	public Object getItem(int position) {

		return null;
	}

	@Override
	public long getItemId(int position) {

		return 0;
	}

	@Override
	public View getView(int position, View convertview, ViewGroup parent) {
		ViewHolder holder = null;
		if (convertview == null) {
			holder = new ViewHolder();
			convertview = infater.inflate(R.layout.listview_item_comment, null);
			holder.tvMsg = (TextView) convertview.findViewById(R.id.tvMsg);
			holder.tvCreateTime = (TextView) convertview
					.findViewById(R.id.tvCreateTime);

			convertview.setTag(holder);
		} else {
			holder = (ViewHolder) convertview.getTag();
		}

		holder.tvCreateTime.setText(list.get(position).getUsername() + " ������:"
				+ list.get(position).getCreatetime());
		holder.tvMsg.setText(list.get(position).getComment());

		holder.tvMsg.setTag(list.get(position).getId());
		return convertview;
	}

	class ViewHolder {

		private TextView tvMsg;

		private TextView tvCreateTime;

	}

}
