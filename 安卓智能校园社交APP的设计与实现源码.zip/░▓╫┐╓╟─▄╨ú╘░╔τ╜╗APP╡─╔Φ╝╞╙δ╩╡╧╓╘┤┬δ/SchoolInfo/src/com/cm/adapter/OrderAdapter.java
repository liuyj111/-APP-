package com.cm.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cm.activity.R;
import com.cm.bean.orders;

public class OrderAdapter extends BaseAdapter {
	private List<orders> list = null;
	private final Context context;
	private LayoutInflater infater = null;
	private boolean isSelf = false;

	public OrderAdapter(Context context, List<orders> list, boolean isSelf) {
		this.infater = LayoutInflater.from(context);
		this.list = list;
		this.context = context;
		this.isSelf = isSelf;
	}

	@Override
	public int getCount() {

		return list.size();
	}

	@Override
	public Object getItem(int position) {

		return null;
	}

	@Override
	public long getItemId(int position) {

		return 0;
	}

	@Override
	public View getView(int position, View convertview, ViewGroup parent) {
		ViewHolder holder = null;
		if (convertview == null) {
			holder = new ViewHolder();
			convertview = infater.inflate(R.layout.listview_item_pro, null);
			holder.ivImage = (ImageView) convertview.findViewById(R.id.ivImage);
			holder.tvProName = (TextView) convertview
					.findViewById(R.id.tvProName);
			holder.tvName = (TextView) convertview.findViewById(R.id.tvName);
			holder.tvCreateTime = (TextView) convertview
					.findViewById(R.id.tvCreateTime);
			holder.tvState = (TextView) convertview.findViewById(R.id.tvState);
			holder.tvIntro = (TextView) convertview.findViewById(R.id.tvIntro);

			convertview.setTag(holder);
		} else {
			holder = (ViewHolder) convertview.getTag();
		}

		return convertview;
	}

	class ViewHolder {
		private ImageView ivImage;
		private TextView tvProName;
		private TextView tvName;
		private TextView tvCreateTime;
		private TextView tvState;
		private TextView tvIntro;

	}

}
