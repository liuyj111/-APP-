package com.cm.activity;

import com.cm.network.NetworkConfig;
import com.cm.utils.BaseApplication;

/**
 * ����ά��ϵͳ������Ϣ
 * 
 * @author
 * 
 */
public class CommonApplication extends BaseApplication {

	@Override
	public void onCreate() {
		super.onCreate();
		isOpenTranslucentStatus = true;
		NetworkConfig.setConfig(new AppConstant());
	}

}
