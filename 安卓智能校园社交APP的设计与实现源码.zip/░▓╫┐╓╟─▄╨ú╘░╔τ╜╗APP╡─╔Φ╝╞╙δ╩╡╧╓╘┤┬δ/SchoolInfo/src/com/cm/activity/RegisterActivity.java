package com.cm.activity;

import java.util.List;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.cm.bean.tb_user;
import com.cm.network.AsyncRequestUtils;
import com.cm.network.AsyncRequestUtils.AsyncListener;
import com.cm.utils.BaseActivity;
import com.cm.utils.BaseUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class RegisterActivity extends BaseActivity {

	private Button btnLogin, btnRegister;
	private EditText etLoginID, etPassword, etPasswordOK, etName, etPhone,
			etCode;

	private int id = 0;
	private List<tb_user> list;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		findview();

		if (user != null) {
			id = user.getId();
			((TextView) findViewById(R.id.tvTopTitleCenter)).setText("�޸���Ϣ");
			etLoginID.setText(user.getLoginid());
			etName.setText(user.getName());
			btnRegister.setText("�޸�");
			btnLogin.setVisibility(View.GONE);
			etLoginID.setEnabled(false);
			query();
		}

	}

	private void findview() {
		((TextView) findViewById(R.id.tvTopTitleCenter)).setText("ע��");
		btnLogin = (Button) findViewById(R.id.btnLogin);
		btnRegister = (Button) findViewById(R.id.btnRegister);
		etLoginID = (EditText) findViewById(R.id.etLoginID);
		etPassword = (EditText) findViewById(R.id.etPassword);

		etPhone = (EditText) findViewById(R.id.etPhone);
		etCode = (EditText) findViewById(R.id.etCode);

		etPasswordOK = (EditText) findViewById(R.id.etPasswordOK);
		etName = (EditText) findViewById(R.id.etName);
		btnRegister.setOnClickListener(this);

		btnLogin.setOnClickListener(this);
	}

	private void register() {
		if (etLoginID.getText().length() == 0) {
			toastUtil.show("�������˺�");
			return;
		}

		if (etName.getText().length() == 0) {
			toastUtil.show("����������");
			return;
		}
		if (etPassword.getText().length() == 0) {
			toastUtil.show("����������");
			return;
		}

		if (etPasswordOK.getText().length() == 0) {
			toastUtil.show("���ٴ���������");
			return;
		}
		if (!etPassword.getText().toString()
				.equals(etPasswordOK.getText().toString())) {
			toastUtil.show("������������벻һ��");
			return;
		}

		BaseUtil.HideKeyboard(this);

		mParamMaps.clear();
		mParamMaps.put("Action", "register");
		mParamMaps.put("id", id);
		mParamMaps.put("loginid", etLoginID.getText());
		mParamMaps.put("password", etPassword.getText());
		mParamMaps.put("name", etName.getText());
		mParamMaps.put("phone", etPhone.getText());
		mParamMaps.put("code", etCode.getText());
		showProgressDialog("������,���Ժ�..");
		AsyncRequestUtils.newInstance().post(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();

				if (result != null && result.trim().equals("1")) {
					if (id == 0) {
						toastUtil.show("ע��ɹ�");

					} else {
						toastUtil.show("�޸ĳɹ�");
						user.setLoginid(etLoginID.getText().toString());
						user.setName(etName.getText().toString());
						application.setLoginUser(user);
					}

					finish();
				} else {
					toastUtil.show("ע��ʧ��");
				}

			}

		});
	}

	private void query() {
		mParamMaps.clear();
		mParamMaps.put("Action", "getOneRow");
		mParamMaps.put("Table", "tb_user");
		mParamMaps.put("ID", user.getId());
		showProgressDialog("��ȡ��..");
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();
				if (!TextUtils.isEmpty(result) && result.trim().length() > 0) {
					list = new Gson().fromJson(result,
							new TypeToken<List<tb_user>>() {
							}.getType());
					if (list != null && list.size() > 0) {

						etLoginID.setText(list.get(0).getLoginid());
						etName.setText(list.get(0).getName());
						etPassword.setText(list.get(0).getPassword());
						etPasswordOK.setText(list.get(0).getPassword());
						etPhone.setText(list.get(0).getPhone());
						etCode.setText(list.get(0).getCode());
					}
				}
			}
		});
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnLogin:
			finish();
			break;
		case R.id.btnRegister:
			register();
			break;
		default:
			break;
		}
	}

}
