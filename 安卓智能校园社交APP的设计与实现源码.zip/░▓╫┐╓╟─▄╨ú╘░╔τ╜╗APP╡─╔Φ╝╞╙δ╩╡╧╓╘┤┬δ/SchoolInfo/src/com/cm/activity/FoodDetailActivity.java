package com.cm.activity;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.cm.adapter.CommentAdapter;
import com.cm.bean.tb_comment;
import com.cm.bean.tb_foods;
import com.cm.network.AsyncRequestUtils;
import com.cm.network.AsyncRequestUtils.AsyncListener;
import com.cm.utils.ActivityUtils;
import com.cm.utils.AsyncImageLoader;
import com.cm.utils.BaseActivity;
import com.cm.utils.BaseUtil;
import com.cm.utils.UIUtils;
import com.google.gson.Gson;

public class FoodDetailActivity extends BaseActivity {
	private final String filepath = "";
	private ImageView imageView1;

	private TextView tvIntro;
	private Button btnTopTitleRight, btnTopTitleLeft;
	private tb_foods model;
	private final Gson gson = new Gson();
	private ListView listview1;
	private CommentAdapter adapter;
	private List<tb_comment> list;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fooddetail);
		model = (tb_foods) getIntent().getSerializableExtra("model");
		findview();
		queryComment();
	}

	private void findview() {
		((TextView) findViewById(R.id.tvTopTitleCenter)).setText("��ʳ��Ϣ");

		btnTopTitleLeft = (Button) findViewById(R.id.btnTopTitleLeft);
		btnTopTitleLeft.setVisibility(View.VISIBLE);
		btnTopTitleLeft.setOnClickListener(this);
		btnTopTitleLeft.setText("����");

		btnTopTitleRight = (Button) findViewById(R.id.btnTopTitleRight);
		btnTopTitleRight.setVisibility(View.VISIBLE);
		btnTopTitleRight.setOnClickListener(this);
		btnTopTitleRight.setText("����");
		listview1 = (ListView) findViewById(R.id.listview1);
		imageView1 = (ImageView) findViewById(R.id.imageView1);
		tvIntro = (TextView) findViewById(R.id.tvIntro);

		init();
	}

	private void init() {
		String intro = "��ʳ����:" + model.getName();
		intro += "\nʳ��:" + model.getMaterial();
		intro += "\n����:" + model.getSteps();
		intro += "\n��ע:" + model.getIntro() + "\n���ۣ�";
		tvIntro.setText(intro);

		if (!TextUtils.isEmpty(model.getImg_url())) {
			AsyncImageLoader.getInstance().loadBitmap(model.getImg_url(),
					imageView1);
		}
	}

	private void queryComment() {
		showProgressDialog("������,���Ժ�..");
		mParamMaps.clear();
		mParamMaps.put("Action", "getcomment");
		mParamMaps.put("id", model.getId());
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();

				list = new ArrayList<tb_comment>();
				if (result != null && result.trim().length() > 0) {
					try {
						jsonArray = new JSONArray(result);
						for (int i = 0; i < jsonArray.length(); i++) {
							jsonObject = jsonArray.getJSONObject(i);
							tb_comment model = new tb_comment();
							model.setId(jsonObject.getInt("id"));
							model.setCreatetime(jsonObject
									.getString("createtime"));
							model.setUsername(jsonObject.getString("username"));
							model.setUserid(jsonObject.getInt("userid"));
							model.setComment(jsonObject.getString("comment"));
							list.add(model);
						}

					} catch (JSONException e) {
						e.printStackTrace();
					}
				}
				BaseUtil.LogE("size = " + list.size());
				adapter = new CommentAdapter(FoodDetailActivity.this, list);
				listview1.setAdapter(adapter);

				UIUtils.setListViewHeightBasedOnChildren(listview1);
			}

		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 1 && resultCode == RESULT_OK) {
			queryComment();
		}
	}

	private void share() {
		Intent shareIntent = new Intent();
		shareIntent.setAction(Intent.ACTION_SEND);
		shareIntent.putExtra(Intent.EXTRA_TEXT, model.getName());
		shareIntent.setType("text/plain");

		// ���ñ��⣨���������б��Ľ�����⣩��
		startActivity(Intent.createChooser(shareIntent, "������"));
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnTopTitleLeft:
			share();
			break;
		case R.id.btnTopTitleRight:
			if (!Utils.isLogin()) {
				ActivityUtils.startActivity(LoginActivity.class);
				return;
			}

			intent = new Intent(FoodDetailActivity.this, CommentActivity.class);
			intent.putExtra("id", model.getId());
			startActivityForResult(intent, 1);
			break;
		default:
			break;
		}

	}

}
