package com.cm.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.cm.network.AsyncRequestUtils;
import com.cm.network.AsyncRequestUtils.AsyncListener;
import com.cm.utils.BaseActivity;
import com.cm.utils.BaseUtil;

public class CommentActivity extends BaseActivity {

	private TextView tvTopTitleCenter;
	private Button btnTopTitleRight;
	private Button btnOK;
	private EditText etBody;
	private int id;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_comment);
		id = getIntent().getIntExtra("id", 0);
		findview();

	}

	private void findview() {
		tvTopTitleCenter = (TextView) findViewById(R.id.tvTopTitleCenter);
		tvTopTitleCenter.setText("����");
		etBody = (EditText) findViewById(R.id.etBody);
		btnOK = (Button) findViewById(R.id.btnOK);
		btnOK.setOnClickListener(this);

	}

	private void submit() {
		if (etBody.getText().length() == 0) {
			toastUtil.show("����������");
			return;
		}

		BaseUtil.HideKeyboard(this);
		mParamMaps.clear();
		mParamMaps.put("Action", "comment");
		mParamMaps.put("proid", id);
		mParamMaps.put("userid", user.getId());
		mParamMaps.put("comment", etBody.getText());
		showProgressDialog("������,���Ժ�..");
		AsyncRequestUtils.newInstance().post(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();
				if (result.trim().equals("1")) {
					toastUtil.show("���۳ɹ�");
					setResult(RESULT_OK);
					finish();
				} else {
					toastUtil.show("����ʧ��");
				}

			}

		});
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnLogin:
			finish();
			break;
		case R.id.btnTopTitleRight:

			break;

		case R.id.btnOK:
			submit();
			break;
		}
	}

}
