package com.cm.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.cm.adapter.FoodAdapter;
import com.cm.bean.tb_foods;
import com.cm.network.AsyncRequestUtils;
import com.cm.network.AsyncRequestUtils.AsyncListener;
import com.cm.utils.BaseActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class FoodListActivity extends BaseActivity {
	private TextView tvTopTitleCenter;
	private Button btnTopTitleLeft, btnTopTitleRight;
	private List<tb_foods> list;
	private FoodAdapter adapter;
	private ListView listview1;
	private String keyword = "";
	private final Gson gson = new Gson();
	private int row;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list);
		findview();
		query();
	}

	private void findview() {
		tvTopTitleCenter = (TextView) findViewById(R.id.tvTopTitleCenter);
		tvTopTitleCenter.setText("��ʳ");

		btnTopTitleRight = (Button) findViewById(R.id.btnTopTitleRight);
		btnTopTitleRight.setOnClickListener(this);
		btnTopTitleRight.setText("����");
		btnTopTitleRight.setVisibility(View.VISIBLE);
		btnTopTitleRight.setBackgroundResource(R.drawable.btn_comm_selector);
		listview1 = (ListView) findViewById(R.id.listview1);
		listview1.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				row = position;
				intent = new Intent(FoodListActivity.this,
						FoodDetailActivity.class);
				intent.putExtra("model", list.get(row));
				startActivity(intent);
			}

		});
	}

	private void query() {
		showProgressDialog("������,���Ժ�..");
		mParamMaps.clear();
		mParamMaps.put("Action", "getfoodlist");
		mParamMaps.put("name", keyword);
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();
				list = new ArrayList<tb_foods>();
				if (result != null && result.trim().length() > 0) {
					list = gson.fromJson(result,
							new TypeToken<List<tb_foods>>() {
							}.getType());

				}

				adapter = new FoodAdapter(FoodListActivity.this, list);
				listview1.setAdapter(adapter);

			}

		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 1 && resultCode == 1) {
			query();
		}
	}

	private void search() {
		final EditText eText = new EditText(this);
		AlertDialog dialog = new AlertDialog.Builder(this).setTitle("����")
				.setIcon(android.R.drawable.ic_dialog_info).setView(eText)
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						keyword = eText.getText().toString();
						query();
					}

				}).setNegativeButton("ȡ��", null).create();
		dialog.show();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnTopTitleRight:
			search();
			break;
		case R.id.btnTopTitleLeft:
			break;
		default:
			break;
		}

	}
}
