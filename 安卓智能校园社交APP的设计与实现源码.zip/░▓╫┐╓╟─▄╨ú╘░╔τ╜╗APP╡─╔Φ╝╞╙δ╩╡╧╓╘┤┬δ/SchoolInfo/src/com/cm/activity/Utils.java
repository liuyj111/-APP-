package com.cm.activity;

import com.cm.utils.BaseApplication;

public class Utils {

	public static boolean isLogin() {
		BaseApplication application = (BaseApplication) BaseApplication
				.getContext();
		return application.getOnlineUser() != null;
	}
}
