package com.cm.activity;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.cm.adapter.NewsAdapter;
import com.cm.bean.tb_news;
import com.cm.utils.BaseActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class NewListActivity extends BaseActivity {
	private TextView tvTopTitleCenter;
	private final String id = "";
	private Button btnTopTitleRight, btnTopTitleLeft;
	private ListView listview1;
	private NewsAdapter adapter;
	private List<tb_news> list;
	private final Gson gson = new Gson();
	private boolean isShow = true;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list);
		findview();

	}

	private void findview() {
		tvTopTitleCenter = (TextView) findViewById(R.id.tvTopTitleCenter);
		tvTopTitleCenter.setText("У԰����");

		listview1 = (ListView) findViewById(R.id.listview1);
		listview1.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				intent = new Intent(NewListActivity.this, NewViewActivity.class);
				intent.putExtra("model", list.get(position));
				startActivity(intent);

			}
		});
	}

	private class loadAsyncTask extends AsyncTask<String, Integer, String> {
		@Override
		protected void onPreExecute() {
			if (isShow) {
				showProgressDialog("������...");
				isShow = false;
			}

		}

		@Override
		protected String doInBackground(String... params) {
			String urlString = AppConstant.getUrl(getApplicationContext())
					+ "ServletService?Action=getnewlist";
			String json = httpHelper.HttpRequest(urlString);
			return json;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			hideProgressDialog();
			if (!TextUtils.isEmpty(result) && result.trim().length() > 0) {
				list = gson.fromJson(result, new TypeToken<List<tb_news>>() {
				}.getType());

			} else {
				list = new ArrayList<tb_news>();
			}
			adapter = new NewsAdapter(NewListActivity.this, list);
			listview1.setAdapter(adapter);
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		new loadAsyncTask().execute();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnTopTitleRight:

			break;
		case R.id.btnTopTitleLeft:

			break;
		default:
			break;
		}

	}

}
