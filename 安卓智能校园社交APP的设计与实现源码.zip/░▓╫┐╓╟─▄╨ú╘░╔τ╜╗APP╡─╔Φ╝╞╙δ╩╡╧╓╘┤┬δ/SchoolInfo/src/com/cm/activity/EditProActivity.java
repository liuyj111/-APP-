package com.cm.activity;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.cm.bean.tb_pro;
import com.cm.bean.tb_types;
import com.cm.component.ChooseImageDialog;
import com.cm.component.ChooseImageDialog.OnResultListener;
import com.cm.network.AsyncRequestUtils;
import com.cm.network.AsyncRequestUtils.AsyncListener;
import com.cm.utils.AsyncImageLoader;
import com.cm.utils.BaseActivity;
import com.cm.utils.BaseUtil;
import com.cm.utils.UIUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class EditProActivity extends BaseActivity {

	private TextView tvTopTitleCenter;

	private String filepath = "";
	private Button btnTopTitleRight;
	private EditText etQuality, etPrice, etProName, etProIntro;

	private int id = 0;
	private ImageView ivImage;
	private List<tb_types> listTypes;
	private final Gson gson = new Gson();
	private tb_pro model;
	private Spinner spinner1;
	private Button btnOK;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_issuepro);
		model = (tb_pro) getIntent().getSerializableExtra("model");
		findview();
		queryTypes();
		if (model == null) {
			tvTopTitleCenter.setText("������Ϣ");
		} else {
			tvTopTitleCenter.setText("�޸���Ϣ");
		}
	}

	private void findview() {
		tvTopTitleCenter = (TextView) findViewById(R.id.tvTopTitleCenter);
		btnOK = (Button) findViewById(R.id.btnOK);
		btnOK.setOnClickListener(this);
		btnOK.setText("���");

		spinner1 = (Spinner) findViewById(R.id.spinner1);
		etQuality = (EditText) findViewById(R.id.etQuality);
		etPrice = (EditText) findViewById(R.id.etPrice);

		ivImage = (ImageView) findViewById(R.id.ivImage);
		ivImage.setOnClickListener(this);
		ivImage.setOnLongClickListener(new OnLongClickListener() {
			@Override
			public boolean onLongClick(View v) {
				filepath = "";
				ivImage.setImageResource(R.drawable.btn_choose_picture);
				return true;
			}
		});

		etProName = (EditText) findViewById(R.id.etProName);
		etProIntro = (EditText) findViewById(R.id.etProIntro);

		if (model != null) {
			id = model.getId();
			etProName.setText(model.getProname());
			etProIntro.setText(model.getIntro());
			etPrice.setText(model.getPrice() + "");
			etQuality.setText(model.getQuality() + "");

			AsyncImageLoader.getInstance().loadBitmap(model.getFilepath(),
					ivImage);
		}

	}

	private void queryTypes() {
		mParamMaps.clear();
		mParamMaps.put("Action", "getOneRow");
		mParamMaps.put("Table", "tb_types");
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				listTypes = new ArrayList<tb_types>();
				if (result != null && result.trim().length() > 0) {
					listTypes = gson.fromJson(result,
							new TypeToken<List<tb_types>>() {
							}.getType());

				}
				String[] strs = new String[listTypes.size()];
				for (int i = 0; i < listTypes.size(); i++) {
					strs[i] = listTypes.get(i).getName();
				}
				UIUtils.bindSpinner(EditProActivity.this, spinner1, strs);
				if (model != null) {
					for (int j = 0; j < listTypes.size(); j++) {
						if (listTypes.get(j).getId() == model.getTypeid()) {
							spinner1.setSelection(j);
							break;
						}
					}
				}
			}

		});
	}

	private void submit() {
		if (etProName.getText().length() == 0) {
			toastUtil.show("���������");
			return;
		}

		if (etQuality.getText().length() == 0) {
			toastUtil.show("�������ɫ");
			return;
		}

		if (etPrice.getText().length() == 0) {
			toastUtil.show("������۸�");
			return;
		}

		if (TextUtils.isEmpty(filepath) && id == 0) {
			toastUtil.show("��ѡ��ͼƬ");
			return;
		}

		BaseUtil.HideKeyboard(this);

		mParamMaps.clear();
		mParamMaps.put("Action", "editpro");
		mParamMaps.put("id", model != null ? model.getId() : 0);
		mParamMaps.put("userid", user.getId());
		mParamMaps.put("intro", etProIntro.getText());
		mParamMaps.put("proname", etProName.getText());
		mParamMaps.put("state", "������");
		mParamMaps.put("quality", etQuality.getText());
		mParamMaps.put("typeid",
				listTypes.get(spinner1.getSelectedItemPosition()).getId());
		mParamMaps.put("price", etPrice.getText());
		showProgressDialog("������,���Ժ�..");
		AsyncRequestUtils.newInstance().post(filepath, mParamMaps,
				new AsyncListener() {
					@Override
					public void onResult(String result) {
						hideProgressDialog();
						if (result.trim().equals("1")) {
							toastUtil.show("�ύ�ɹ�");
							setResult(RESULT_OK);
							finish();
						} else {
							toastUtil.show("�ύʧ��");
						}
					}

				});
	}

	private class ChooseResultListener implements OnResultListener {
		@Override
		public void onResult(int mode, String path) {
			filepath = path;
			UIUtils.loadImageAvoidOOM(ivImage, path);
		}

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.ivImage:// ѡ��ͼƬ
			ChooseImageDialog.getInstance().show(EditProActivity.this,
					new ChooseResultListener());
			break;
		case R.id.btnOK:// ��ɰ�ť
			submit();
			break;
		default:
			break;
		}

	}

}
