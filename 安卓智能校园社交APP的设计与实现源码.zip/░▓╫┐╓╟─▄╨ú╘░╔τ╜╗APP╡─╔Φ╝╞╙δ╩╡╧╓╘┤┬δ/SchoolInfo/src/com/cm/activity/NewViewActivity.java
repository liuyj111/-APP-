package com.cm.activity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.cm.bean.tb_news;
import com.cm.utils.AsyncImageLoader;
import com.cm.utils.BaseActivity;
import com.cm.utils.BaseUtil;

public class NewViewActivity extends BaseActivity {
	private String id;
	private WebView webView1;
	private Button btnTopTitleLeft;
	private TextView tvTopTitleCenter;
	private tb_news model;
	private ImageView imageView1;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new_view);
		model = (tb_news) getIntent().getSerializableExtra("model");
		findview();

	}

	private void findview() {
		tvTopTitleCenter = (TextView) findViewById(R.id.tvTopTitleCenter);
		tvTopTitleCenter.setText("У԰��������");

		imageView1 = (ImageView) findViewById(R.id.imageView1);
		webView1 = (WebView) findViewById(R.id.webview1);
		btnTopTitleLeft = (Button) findViewById(R.id.btnTopTitleLeft);
		btnTopTitleLeft.setVisibility(View.VISIBLE);
		btnTopTitleLeft.setOnClickListener(this);
		btnTopTitleLeft.setText("����");

		WebSettings webSettings = webView1.getSettings();
		webSettings.setJavaScriptEnabled(true);
		webSettings.setDefaultFontSize(18);
		webSettings.setLoadWithOverviewMode(true);
		webSettings.setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		webView1.setWebViewClient(new theWebViewClient());
		webView1.setWebChromeClient(new theWebChromeClient());

		String body = "<style type='text/css'>*{color:#666;}</style><div style='padding:3px;'>";
		body += "<p>" + model.getTitle() + "</p>";
		body += "<div style='padding:10px;'>" + ReplaceImgTag(model.getBody())
				+ "</div>";
		body += "</div>";

		webView1.loadDataWithBaseURL(null, body, "text/html", "utf-8", null);

		AsyncImageLoader.getInstance().loadBitmap(model.getImg_url(),
				imageView1);

	}

	private class theWebChromeClient extends WebChromeClient {
		@Override
		public void onProgressChanged(WebView view, int newProgress) {
			super.onProgressChanged(view, newProgress);

		}
	}

	private class theWebViewClient extends WebViewClient {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			return true;
		}

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {

		}

		@Override
		public void onReceivedError(WebView view, int errorCode,
				String description, String failingUrl) {
			super.onReceivedError(view, errorCode, description, failingUrl);
		}

		@Override
		public void onPageFinished(WebView view, String url) {

		}

	};

	private String ReplaceImgTag(String html) {
		if (html == null)
			return "";
		Pattern patternImgSrc1 = Pattern.compile("<img(.+?)src=(.+?) ");
		Matcher m = patternImgSrc1.matcher(html);
		while (m.find()) {
			html = m.replaceAll("<img width='100%' src=\"http://"
					+ AppConstant.getRootIPHost() + "$2\" ");
		}
		html = html.replace("\"/", "/").replace("\"/Sch", "/Sch")
				.replace(".jpg\"", ".jpg").replace(".png\"", ".png");
		BaseUtil.LogE(html);
		return html;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnTopTitleLeft:
			finish();
			break;
		default:
			break;
		}

	}

}
