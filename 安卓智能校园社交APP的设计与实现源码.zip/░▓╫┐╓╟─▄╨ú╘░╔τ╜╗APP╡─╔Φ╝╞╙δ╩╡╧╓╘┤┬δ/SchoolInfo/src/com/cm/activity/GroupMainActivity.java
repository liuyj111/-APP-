package com.cm.activity;

import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;

import com.cm.utils.ActivityUtils;
import com.cm.utils.SystemUtils;
import com.cm.utils.ToastUtil;

@SuppressWarnings("deprecation")
public class GroupMainActivity extends ActivityGroup {
	private FrameLayout containerBody = null;
	private Button btnModule1, btnModule2, btnModule3, btnModule4;
	private ToastUtil toastUtil;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		SystemUtils.setTranslucentStatus(this);
		setContentView(R.layout.activity_main_group);
		toastUtil = new ToastUtil(GroupMainActivity.this);
		containerBody = (FrameLayout) findViewById(R.id.containerBody);
		btnModule1 = (Button) findViewById(R.id.btnModule1);
		btnModule2 = (Button) findViewById(R.id.btnModule2);
		btnModule3 = (Button) findViewById(R.id.btnModule3);
		btnModule4 = (Button) findViewById(R.id.btnModule4);
		btnModule1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				changeBottomiButton(0);
				containerBody.removeAllViews();
				containerBody.addView(getLocalActivityManager().startActivity(
						"Module1",
						new Intent(GroupMainActivity.this,
								ProListActivity.class)).getDecorView());

			}
		});
		btnModule2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				changeBottomiButton(1);
				containerBody.removeAllViews();
				containerBody.addView(getLocalActivityManager().startActivity(
						"Module2",
						new Intent(GroupMainActivity.this,
								NewListActivity.class)).getDecorView());

			}
		});
		btnModule3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				changeBottomiButton(2);
				containerBody.removeAllViews();
				containerBody.addView(getLocalActivityManager().startActivity(
						"Module3",
						new Intent(GroupMainActivity.this,
								FoodListActivity.class)).getDecorView());
			}
		});
		btnModule4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!Utils.isLogin()) {
					ActivityUtils.startActivity(LoginActivity.class);
					return;
				}

				changeBottomiButton(3);
				containerBody.removeAllViews();
				containerBody.addView(getLocalActivityManager().startActivity(
						"Module4",
						new Intent(GroupMainActivity.this,
								PersonCenterActivity.class)).getDecorView());
			}
		});
		btnModule1.performClick();
	}

	protected void changeBottomiButton(int index) {
		switch (index) {
		case 0:
			btnModule1.setBackgroundColor(getResources().getColor(
					R.color.common_color_pre));
			btnModule2.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			btnModule3.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			btnModule4.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			break;
		case 1:
			btnModule1.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			btnModule2.setBackgroundColor(getResources().getColor(
					R.color.common_color_pre));
			btnModule3.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			btnModule4.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			break;
		case 2:
			btnModule1.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			btnModule2.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			btnModule3.setBackgroundColor(getResources().getColor(
					R.color.common_color_pre));
			btnModule4.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			break;
		case 3:
			btnModule1.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			btnModule2.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			btnModule3.setBackgroundColor(getResources().getColor(
					R.color.common_color_nor));
			btnModule4.setBackgroundColor(getResources().getColor(
					R.color.common_color_pre));
			break;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0, 99, 0, "�޸���Ϣ");
		menu.add(0, 100, 0, "�˳�");
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		super.onOptionsItemSelected(item);
		switch (item.getItemId()) {
		case 99:
			ActivityUtils.startActivity(RegisterActivity.class);
			break;
		case 100:// �˳�
			System.exit(0);
			break;
		}
		return false;
	}

}
