package com.cm.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.cm.adapter.ProAdapter;
import com.cm.bean.tb_pro;
import com.cm.network.AsyncRequestUtils;
import com.cm.network.AsyncRequestUtils.AsyncListener;
import com.cm.utils.BaseActivity;
import com.cm.utils.BaseUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class MyProActivity extends BaseActivity {
	private TextView tvTopTitleCenter;
	private Button btnTopTitleRight;
	private List<tb_pro> list;
	private ProAdapter adapter;
	private ListView listview1;
	private int row;
	private final Gson gson = new Gson();
	private int type;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list);
		type = getIntent().getIntExtra("type", 1);
		findview();
		query();
	}

	private void findview() {
		tvTopTitleCenter = (TextView) findViewById(R.id.tvTopTitleCenter);

		btnTopTitleRight = (Button) findViewById(R.id.btnTopTitleRight);
		btnTopTitleRight.setOnClickListener(this);
		btnTopTitleRight.setText("����");
		btnTopTitleRight.setBackgroundResource(R.drawable.btn_comm_selector);
		listview1 = (ListView) findViewById(R.id.listview1);
		listview1.setOnItemLongClickListener(new OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					int position, long id) {
				row = position;
				if (type == 1) {
					showContactDialog();
				}
				return true;
			}

		});
		listview1.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				row = position;
				intent = new Intent(MyProActivity.this, ProDetailActivity.class);
				intent.putExtra("model", list.get(row));
				startActivity(intent);
			}

		});

		if (type == 1) {
			tvTopTitleCenter.setText("�ҵ���Ʒ");
			btnTopTitleRight.setVisibility(View.VISIBLE);
		}
		if (type == 2) {
			tvTopTitleCenter.setText("�ҵ��ղ�");
		}

	}

	private void query() {
		showProgressDialog("������,���Ժ�..");
		mParamMaps.clear();
		mParamMaps.put("Action", "getprolist");
		mParamMaps.put("userid", user.getId());
		if (type == 2) {
			mParamMaps.put("iscollect", 1);
		}
		if (type == 3) {
			mParamMaps.put("iszan", 1);
		}
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();

				list = new ArrayList<tb_pro>();
				if (result != null && result.trim().length() > 0) {
					list = gson.fromJson(result, new TypeToken<List<tb_pro>>() {
					}.getType());

				} else {
					toastUtil.show("û������");
				}
				adapter = new ProAdapter(MyProActivity.this, list, true);
				listview1.setAdapter(adapter);

			}

		});
	}

	private String[] arg;

	private void showContactDialog() {
		String[] arg;
		if (list.get(row).getState().equals("���¼�")) {
			arg = new String[] { "�޸�", "ɾ��", "�ϼ�" };
		} else {
			arg = new String[] { "�޸�", "ɾ��", "�¼�" };
		}
		new AlertDialog.Builder(this).setTitle("ѡ�����")
				.setItems(arg, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						BaseUtil.LogII("which  99 " + which);
						switch (which) {
						case 0:// �޸�
							intent = new Intent(MyProActivity.this,
									EditProActivity.class);
							intent.putExtra("model", list.get(row));
							startActivityForResult(intent, 1);
							break;
						case 1:// ɾ��
							delete();
							break;
						case 2:// �޸�״̬
							change();

							break;
						}
					}
				}).show();
	}

	private void delete() {
		showProgressDialog("ɾ����,���Ժ�..");
		buildDeleteMap("tb_pro", list.get(row).getId());
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();

				if (!TextUtils.isEmpty(result) && result.trim().length() > 0) {
					toastUtil.show("ɾ���ɹ�");
					list.remove(row);
					adapter.notifyDataSetChanged();
				} else {
					toastUtil.show("ɾ��ʧ��");
					dialog.dismiss();
				}

			}

		});
	}

	private void change() {
		showProgressDialog("������,���Ժ�..");
		mParamMaps.clear();
		mParamMaps.put("Action", "changestate");
		mParamMaps.put("id", list.get(row).getId());
		if (list.get(row).getState().equals("���¼�")) {
			mParamMaps.put("state", "������");
		} else {
			mParamMaps.put("state", "���¼�");
		}

		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();

				if (result != null && result.trim().length() > 0) {
					toastUtil.show("�����ɹ�");
					query();
				} else {
					toastUtil.show("����ʧ��");
				}

			}

		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 1 && resultCode == RESULT_OK) {
			query();
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnTopTitleRight:
			intent = new Intent(MyProActivity.this, EditProActivity.class);
			startActivityForResult(intent, 1);
			break;
		default:
			break;
		}

	}
}
