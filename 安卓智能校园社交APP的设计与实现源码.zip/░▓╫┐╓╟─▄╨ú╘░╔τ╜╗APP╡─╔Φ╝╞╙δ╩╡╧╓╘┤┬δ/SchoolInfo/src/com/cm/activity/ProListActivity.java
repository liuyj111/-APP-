package com.cm.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.cm.adapter.ProAdapter;
import com.cm.bean.tb_pro;
import com.cm.bean.tb_types;
import com.cm.network.AsyncRequestUtils;
import com.cm.network.AsyncRequestUtils.AsyncListener;
import com.cm.utils.BaseActivity;
import com.cm.utils.UIUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * ��Ʒ����
 * 
 * @author zlus
 * 
 */
public class ProListActivity extends BaseActivity {
	private TextView tvTopTitleCenter;
	private Button btnTopTitleRight;
	private List<tb_pro> list;
	private ProAdapter adapter;
	private ListView listview1;
	private String keyword = "";
	private double quality;
	private int typeid;
	private int row;
	private final Gson gson = new Gson();
	private List<tb_types> listTypes;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list);
		findview();
		query();
	}

	private void findview() {
		tvTopTitleCenter = (TextView) findViewById(R.id.tvTopTitleCenter);
		tvTopTitleCenter.setText("������Ʒ");
		btnTopTitleRight = (Button) findViewById(R.id.btnTopTitleRight);
		btnTopTitleRight.setVisibility(View.VISIBLE);
		btnTopTitleRight.setOnClickListener(this);
		btnTopTitleRight.setText("����");
		btnTopTitleRight.setBackgroundResource(R.drawable.btn_comm_selector);
		listview1 = (ListView) findViewById(R.id.listview1);
		listview1.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				row = position;
				intent = new Intent(ProListActivity.this,
						ProDetailActivity.class);
				intent.putExtra("model", list.get(row));
				startActivity(intent);
			}
		});

		listview1.setOnItemLongClickListener(new OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					int position, long id) {
				row = position;
				return true;
			}
		});

	}

	private void query() {
		showProgressDialog("������,���Ժ�..");
		mParamMaps.clear();
		mParamMaps.put("Action", "getprolist");
		mParamMaps.put("proname", keyword);
		mParamMaps.put("quality", quality);
		mParamMaps.put("typeid", typeid);
		mParamMaps.put("status", "���ͨ��");
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();
				list = new ArrayList<tb_pro>();
				if (result != null && result.trim().length() > 0) {
					list = gson.fromJson(result, new TypeToken<List<tb_pro>>() {
					}.getType());

				} else {
					toastUtil.show("û������");
				}
				adapter = new ProAdapter(ProListActivity.this, list, false);
				listview1.setAdapter(adapter);
				queryTypes();
			}

		});
	}

	@Override
	public void onResume() {
		super.onResume();
		query();
	}

	private void queryTypes() {
		mParamMaps.clear();
		mParamMaps.put("Action", "getOneRow");
		mParamMaps.put("Table", "tb_types");
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				listTypes = new ArrayList<tb_types>();
				if (result != null && result.trim().length() > 0) {
					listTypes = gson.fromJson(result,
							new TypeToken<List<tb_types>>() {
							}.getType());

				}

			}

		});
	}

	private void search() {
		View view = LayoutInflater.from(this).inflate(R.layout.layout_search,
				null);
		final EditText etName = (EditText) view.findViewById(R.id.etName);
		final EditText etQuality = (EditText) view.findViewById(R.id.etQuality);
		final Spinner spinner1 = (Spinner) view.findViewById(R.id.spinner1);
		String[] strs = new String[listTypes.size() + 1];
		strs[0] = "����";
		for (int i = 0; i < listTypes.size(); i++) {
			strs[i + 1] = listTypes.get(i).getName();
		}
		UIUtils.bindSpinner(this, spinner1, strs);
		AlertDialog dialog = new AlertDialog.Builder(this).setTitle("����")
				.setIcon(android.R.drawable.ic_dialog_info).setView(view)
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						keyword = etName.getText().toString();
						if (etQuality.getText().length() > 0) {
							quality = Double.valueOf(etQuality.getText()
									.toString());
						} else {
							quality = 0;
						}
						if (spinner1.getSelectedItemPosition() != 0) {
							typeid = listTypes.get(
									spinner1.getSelectedItemPosition() - 1)
									.getId();
						} else {
							typeid = 0;
						}
						query();
					}

				}).setNegativeButton("ȡ��", null).create();
		dialog.show();
	}

	private void showMenuDialog() {
		final String[] arg = new String[] { "ɾ��" };
		new AlertDialog.Builder(this).setTitle("ѡ�����")
				.setItems(arg, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						if (arg[which].equals("ɾ��")) {
							delete();
						}
					}
				}).show();
	}

	private void delete() {
		buildDeleteMap("tb_pro", list.get(row).getId());
		showProgressDialog("������..");
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();
				if (result != null && result.trim().length() > 0) {
					toastUtil.show("ɾ���ɹ�");
					list.remove(row);
					adapter.notifyDataSetChanged();
				} else {
					toastUtil.show("ɾ��ʧ��");
				}
			}
		});
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnTopTitleRight:
			search();
			break;
		default:
			break;
		}

	}
}
