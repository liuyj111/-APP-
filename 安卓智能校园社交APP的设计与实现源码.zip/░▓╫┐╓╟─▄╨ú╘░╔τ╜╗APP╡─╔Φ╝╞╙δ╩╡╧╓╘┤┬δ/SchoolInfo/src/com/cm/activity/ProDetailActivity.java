package com.cm.activity;

import java.util.HashMap;
import java.util.List;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.cm.adapter.CommentAdapter;
import com.cm.bean.tb_comment;
import com.cm.bean.tb_pro;
import com.cm.network.AsyncRequestUtils;
import com.cm.network.AsyncRequestUtils.AsyncListener;
import com.cm.utils.ActivityUtils;
import com.cm.utils.AsyncImageLoader;
import com.cm.utils.BaseActivity;
import com.cm.utils.BaseApplication;

/**
 * ��Ʒ�������
 * 
 * @author zlus
 * 
 */
public class ProDetailActivity extends BaseActivity {
	private final String filepath = "";
	private ImageView ivImage;
	private TextView tvProName;
	private TextView tvName;
	private TextView tvCreateTime;
	private TextView tvState;
	private TextView tvIntro;
	private Button btnTopTitleLeft, btnTopTitleRight;

	private ListView listview1;
	private CommentAdapter adapter;
	private List<tb_comment> list;
	private tb_pro model;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_prodetail);
		model = (tb_pro) getIntent().getSerializableExtra("model");
		findview();

	}

	private void findview() {
		((TextView) findViewById(R.id.tvTopTitleCenter)).setText("��Ʒ��Ϣ");

		btnTopTitleRight = (Button) findViewById(R.id.btnTopTitleRight);
		btnTopTitleRight.setVisibility(View.VISIBLE);
		btnTopTitleRight.setOnClickListener(this);
		btnTopTitleRight.setText("�ղ�");

		ivImage = (ImageView) findViewById(R.id.ivImage);
		tvProName = (TextView) findViewById(R.id.tvProName);
		tvName = (TextView) findViewById(R.id.tvName);
		tvCreateTime = (TextView) findViewById(R.id.tvCreateTime);
		tvState = (TextView) findViewById(R.id.tvState);
		tvIntro = (TextView) findViewById(R.id.tvIntro);
		listview1 = (ListView) findViewById(R.id.listview1);

		tvProName.setText(model.getProname());
		tvState.setText("�۸�:" + model.getPrice());
		tvCreateTime.setText("����ʱ�䣺" + model.getCreatetime() + "\n����:"
				+ model.getTypename() + " ��ɫ:" + model.getQuality() + "��");
		tvName.setText("�����ˣ�" + model.getUsername());
		AsyncImageLoader.getInstance().loadBitmap(model.getFilepath(), ivImage);

		String body = "";
		if (Utils.isLogin()) {
			body += "����ϵ�绰����" + model.getPhone();
		}
		if (!TextUtils.isEmpty(body)) {
			body += "\n";
		}
		body += "������" + model.getIntro();
		tvIntro.setText(body);
	}

	private void collect() {
		user = ((BaseApplication) BaseApplication.getContext()).getOnlineUser();
		HashMap<String, Object> mParamMaps = new HashMap<String, Object>();
		mParamMaps.clear();
		mParamMaps.put("Action", "collect");
		mParamMaps.put("proid", model.getId());
		mParamMaps.put("userid", user.getId());
		final ProgressDialog dialog = ProgressDialog.show(this, "��ʾ",
				"������,���Ժ�..");
		AsyncRequestUtils.newInstance().post(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				dialog.dismiss();
				if (result.trim().equals("1")) {
					toastUtil.show("�ղسɹ�");

				} else if (result.trim().equals("-1")) {
					toastUtil.show("�Ѿ��ղع�");
				}
			}
		});
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnTopTitleLeft:
			break;
		case R.id.btnTopTitleRight:
			if (!Utils.isLogin()) {
				ActivityUtils.startActivity(LoginActivity.class);
				return;
			}
			collect();
			break;
		default:
			break;
		}

	}

}
