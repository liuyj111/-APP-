package com.cm.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;

import com.cm.adapter.OrderAdapter;
import com.cm.bean.orders;
import com.cm.network.AsyncRequestUtils;
import com.cm.network.AsyncRequestUtils.AsyncListener;
import com.cm.utils.BaseActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class OrderActivity extends BaseActivity {
	private TextView tvTopTitleCenter;
	private Button btnTopTitleRight;
	private List<orders> list;
	private OrderAdapter adapter;
	private ListView listview1;
	private int row;
	private final Gson gson = new Gson();
	private int type;
	private String startdate, enddate;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list);
		type = getIntent().getIntExtra("type", 0);
		findview();
		query();
	}

	private void findview() {
		tvTopTitleCenter = (TextView) findViewById(R.id.tvTopTitleCenter);

		listview1 = (ListView) findViewById(R.id.listview1);
		listview1.setOnItemLongClickListener(new OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					int position, long id) {
				row = position;
				return true;
			}

		});
		listview1.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				row = position;

			}

		});

		if (type == 1) {
			tvTopTitleCenter.setText("�򵽵�");
		}
		if (type == 2) {
			tvTopTitleCenter.setText("��������");
		}

	}

	private void query() {
		showProgressDialog("������,���Ժ�..");
		mParamMaps.clear();
		mParamMaps.put("Action", "getorderlist");
		mParamMaps.put("userid", user.getId());
		mParamMaps.put("type", type);
		mParamMaps.put("startdate", startdate);
		mParamMaps.put("enddate", enddate);
		AsyncRequestUtils.newInstance().get(mParamMaps, new AsyncListener() {
			@Override
			public void onResult(String result) {
				hideProgressDialog();

				list = new ArrayList<orders>();
				if (result != null && result.trim().length() > 0) {
					list = gson.fromJson(result, new TypeToken<List<orders>>() {
					}.getType());

				} else {
					toastUtil.show("û������");
				}
				adapter = new OrderAdapter(OrderActivity.this, list, true);
				listview1.setAdapter(adapter);

			}

		});
	}

	private void showDateDialog() {
		View view = LayoutInflater.from(this).inflate(
				R.layout.layout_datepicker, null);
		final DatePicker datePicker1 = (DatePicker) view
				.findViewById(R.id.datePicker1);
		final DatePicker datePicker2 = (DatePicker) view
				.findViewById(R.id.datePicker2);

		AlertDialog dialog = new AlertDialog.Builder(this).setTitle("ѡ��")
				.setIcon(android.R.drawable.ic_dialog_info).setView(view)
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						startdate = String.format("%d-%02d-%02d",
								datePicker1.getYear(),
								datePicker1.getMonth() + 1,
								datePicker1.getDayOfMonth());

						enddate = String.format("%d-%02d-%02d",
								datePicker2.getYear(),
								datePicker2.getMonth() + 1,
								datePicker2.getDayOfMonth());
						query();
					}

				}).setNegativeButton("ȡ��", null).create();
		dialog.show();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btnTopTitleRight:
			showDateDialog();
			break;
		default:
			break;
		}

	}
}
